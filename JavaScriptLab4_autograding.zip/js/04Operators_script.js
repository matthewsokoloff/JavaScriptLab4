document.write("04Operators_script.js is linked")
// 1.  Write a JavaScript statement that logs the result of adding 1 and 2 to the console
console.log(1 + 2)

// 2.  Write a JavaScript statement that logs the result of subtracting 3 from 5 to the console
console.log(5 - 3)

// 3.  Write a JavaScript statement that logs the result of multiplying 4 times 2 to the console
console.log(4 * 2)

// 4.  Write a JavaScript statement that logs the result of dividing 5 by 2 to the console
console.log(5 / 2)

// 5.  Write a JavaScript statement that logs the remainder of 5 divided by 2
console.log(5 % 2)

// 6.  Write a JavaScript statement that logs the result of comparing 4 and 2 to see if they are equal (remember == is the comparison operator for equals)
console.log(4 == 2)

// 7.  Write a JavaScript statement that logs the result of 3 squared
console.log(3 ** 2)