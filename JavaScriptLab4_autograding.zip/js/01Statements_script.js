document.write("01Statements_script.js is linked")
// Write a JavaScript statement below that logs "Hello from a statement to the console"
console.log("Hello from a statement")