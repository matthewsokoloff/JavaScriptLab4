document.write("03DataTypes_script.js is linked")
// 1.  Write a JavaScript statement below that logs the data type of "hello" to the console"
console.log(typeof("hello"))

// 2.  Write a JavaScript statement below that logs the data type of 10 to the console"
console.log(typeof(10))


// 3.  Write a JavaScript statement below that logs the data type of 5.5 to the console"
console.log(typeof(5.5))


// 4.  Write a JavaScript statement below that logs the data type of true to the console"
console.log(typeof(true))


// 6.  Write a JavaScript statement below that logs the data type of ["a", "b", "c"] to the console"
console.log(typeof(["a", "b", "c"]))


// 7.  Write a JavaScript statement below that logs the data type of myVariable to the console"
console.log(typeof(myVariable))
