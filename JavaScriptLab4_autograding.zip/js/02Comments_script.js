document.write("02Comments_script.js is linked")
/* Write a single line JavaScript comment below that says "I am a single line comment" */
// I am a single line comment