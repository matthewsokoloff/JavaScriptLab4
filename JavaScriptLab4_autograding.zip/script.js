

/* JavaScript comments are statements that begin with // for a single line comment, or /* for a multi-line comment.  
A single line comment: // single line comment
A multiline comment: /* multiline comment */

// 2. Write a single line comment below that says "I am a single line comment"


